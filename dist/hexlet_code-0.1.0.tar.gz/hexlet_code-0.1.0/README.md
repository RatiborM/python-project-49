### Hexlet tests and linter status:
[![Actions Status](https://github.com/RatiborM/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/RatiborM/python-project-49/actions)
## Демонстрация игры

[![asciicast](https://asciinema.org/a/jJ81w55kL9itg2TON9OhD7xot.svg)](https://asciinema.org/a/jJ81w55kL9itg2TON9OhD7xot)
